"""Core FDTD simulation modules."""
